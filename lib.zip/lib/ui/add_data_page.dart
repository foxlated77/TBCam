import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:tutorial_1/repo/pasien_repo.dart';
import 'package:tutorial_1/ui/daftar_page/register.dart';

import '../bloc/app_blocs.dart';
import '../bloc/app_states.dart';
import '../bloc/pasien_bloc/pasien_blocs.dart';
import '../bloc/pasien_bloc/pasien_states.dart';
import '../repo/product_repo.dart';
import 'daftar_page/form_page.dart';
import 'home_page.dart';


class add_data extends StatelessWidget {
  const add_data({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(

        home:  RepositoryProvider(
          create: (context) => PasienRepository(),
          child: const Home_add_data(),
        )
    );
  }
}

class Home_add_data extends StatelessWidget {
  const Home_add_data({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();

    return BlocProvider(
      create: (context) => PasienBloc(
          pasienRepository:RepositoryProvider.of<PasienRepository>(context)
      ),
      child: Scaffold(
          key: scaffoldKey,
          body: BlocListener<PasienBloc, PasienState>(
              listener: (context, state) {
                if (state is PasienAdded) {
                  ScaffoldMessenger.of(context)
                      .showSnackBar(const SnackBar(content: Text("Pasien added"), duration: Duration(seconds: 2),));
                }
              },
              child: BlocBuilder<PasienBloc, PasienState>(
                builder: (context, state) {
                  if (state is PasienAdding) {
                    return const Center(
                      child: CircularProgressIndicator(),
                    );
                  }else if(state is PasienError){
                    return const Center(child:Text("Error"));

                  }
                  return const Register();
                },
              )
          )
      ),
    );
  }
}
