import 'package:flutter/material.dart';



class menu_pasien extends StatefulWidget {
  const menu_pasien({Key? key}) : super(key: key);

  @override
  _menu_pasienState createState() => _menu_pasienState();
}

class _menu_pasienState extends State<menu_pasien> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(30),
            child: Center(
              child:  Column(
                children: [
                  SizedBox(height: 20,),
                  Image.asset("images/person.png", height: 100,width: 100,),
                  SizedBox(height: 10,),
                  Text("Halo, Mr. James", style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold),),
                  SizedBox(height: 10,),
                  Text("Welcome to TB Dashboard", style: TextStyle(fontSize: 15),),
                  SizedBox(height: 10,),
                  Card(
                      clipBehavior: Clip.antiAlias,
                      elevation: 5,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      child:  Stack(
                        children: [
                          Container(
                            alignment: Alignment.center,
                            child: Image.asset(
                              'images/rekam.jpeg',
                              height: 200,
                              width: double.infinity,
                              fit: BoxFit.cover,
                            ),
                          ),
                          Container(
                              alignment: Alignment.center,
                              child: Padding(
                                padding: EdgeInsets.only(top: 70, left: 170),
                                child:Text(
                                  'Rekam\n Medis',
                                  style: TextStyle(color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 25.0),
                                )
                              )),
                          // Image.asset("images/rekam.jpeg",height: 200,width: 300,),
                          // Text("Rekam Medis", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),

                        ],
                      )
                  ),
                  SizedBox(height: 10,),
                  Card(
                      clipBehavior: Clip.antiAlias,
                      elevation: 5,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      child:  Stack(
                        children: [
                          Container(
                            alignment: Alignment.center,
                            child: Image.asset(
                              'images/time.jpeg',
                              height: 200,
                              width: double.infinity,
                              fit: BoxFit.cover,
                            ),
                          ),
                          Container(
                              alignment: Alignment.center,
                              child: Padding(
                                  padding: EdgeInsets.only(top: 70, left: 190),
                                  child:Text(
                                    'Laporan Minum Obat',
                                    style: TextStyle(color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 25.0),
                                  )
                              )),
                          // Image.asset("images/rekam.jpeg",height: 200,width: 300,),
                          // Text("Rekam Medis", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),

                        ],
                      )
                  ),
                  SizedBox(height: 10,),
                  Card(
                      clipBehavior: Clip.antiAlias,
                      elevation: 5,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      child:  Stack(
                        children: [
                          Container(
                            alignment: Alignment.center,
                            child: Image.asset(
                              'images/doctor.jpeg',
                              height: 200,
                              width: double.infinity,
                              fit: BoxFit.cover,
                            ),
                          ),
                          Container(
                              alignment: Alignment.center,
                              child: Padding(
                                  padding: EdgeInsets.only(top: 70, left: 170),
                                  child:Text(
                                    'Informasi\n Obat',
                                    style: TextStyle(color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 25.0),
                                  )
                              )),
                          // Image.asset("images/rekam.jpeg",height: 200,width: 300,),
                          // Text("Rekam Medis", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),

                        ],
                      )
                  ),
                ],
              ),
            )

          ),
        ),
      ),
    );
  }
}
