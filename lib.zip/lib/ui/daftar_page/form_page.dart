import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:tutorial_1/bloc/app_states.dart';
import 'package:tutorial_1/bloc/pasien_bloc/pasien_events.dart';
import 'package:tutorial_1/bloc/pasien_bloc/pasien_states.dart';
import '../../bloc/pasien_bloc/pasien_blocs.dart';
import '../main.dart';



class form_page extends StatefulWidget {
  const form_page({Key? key}) : super(key: key);

  @override
  _form_pageState createState() => _form_pageState();
}

class _form_pageState extends State<form_page> {
  final TextEditingController _nama = TextEditingController();
  final TextEditingController _nik = TextEditingController();
  final TextEditingController _tanggal_lahir = TextEditingController();
  final TextEditingController _umur = TextEditingController();
  final TextEditingController _alamat = TextEditingController();
  final TextEditingController _nomor_hp = TextEditingController();
  final TextEditingController _tinggi_badan = TextEditingController();
  final TextEditingController _berat_badan = TextEditingController();
  final TextEditingController _alergi_obat= TextEditingController();
  final TextEditingController _status_pengobatan = TextEditingController();
  final TextEditingController _jenin_kelamin = TextEditingController();
  PasienBloc? pasienBloc;
  int? select = -1;
  void onchanged(int? value){
    setState(() {

      if(value ==0){
        _jenin_kelamin.text == "Pria";
      }else{
        _jenin_kelamin.text == "Wanita";
      }
      this.select = value;
    });

  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Register Page"),
        leading: Builder(
          builder: (BuildContext context) {
            return IconButton(
              icon: const Icon(Icons.keyboard_arrow_left),
              onPressed: () { Navigator.push(
                  context, MaterialPageRoute(builder: (_) => Myhome()));},
              tooltip: MaterialLocalizations.of(context).openAppDrawerTooltip,
            );
          },
        ),
      ),
      body: StreamBuilder(
          stream: Stream.periodic(const Duration(seconds: 1)),
          initialData: PasienState,
          builder: (context, snapshot) {
            return SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Text("PENDAFTARAN", style: TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 30),),
                      SizedBox(height: 40,),
                      SizedBox(
                        width: double.infinity,
                        child: Text("Nama Lengkap", textAlign: TextAlign.left,),
                      ),
                      SizedBox(height: 5,),
                      TextField(
                        controller: _nama,
                        decoration: InputDecoration(
                            hintText: "Nama Lengkap",
                            border: OutlineInputBorder()
                        ),
                      ),
                      SizedBox(height: 10,),
                      SizedBox(
                        width: double.infinity,
                        child: Text("NIK", textAlign: TextAlign.left,),
                      ),
                      TextField(
                        controller: _nik,
                        decoration: InputDecoration(
                            hintText: "NIK",
                            border: OutlineInputBorder()
                        ),
                      ),
                      SizedBox(height: 10,),
                      SizedBox(
                        width: double.infinity,
                        child: Text(
                          "Tanggal Lahir", textAlign: TextAlign.left,),
                      ),
                      TextField(
                        controller: _tanggal_lahir,
                        decoration: InputDecoration(
                            hintText: "Tanggal Lahir",
                            border: OutlineInputBorder()
                        ),
                      ),
                      SizedBox(height: 10,),
                      SizedBox(
                        width: double.infinity,
                        child: Text("Umur", textAlign: TextAlign.left,),
                      ),
                      TextField(
                        controller: _umur,
                        decoration: InputDecoration(
                            hintText: "Umur",
                            border: OutlineInputBorder()
                        ),
                      ),
                      SizedBox(height: 10,),
                      SizedBox(
                        width: double.infinity,
                        child: Text("Alamat", textAlign: TextAlign.left,),
                      ),
                      TextField(
                        controller: _alamat,
                        decoration: InputDecoration(
                            hintText: "Alamat",
                            border: OutlineInputBorder()
                        ),
                      ),
                      SizedBox(height: 10,),
                      SizedBox(
                        width: double.infinity,
                        child: Text("Nomor HP", textAlign: TextAlign.left,),
                      ),
                      TextField(
                        controller: _nomor_hp,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                            hintText: "Nomor HP",
                            border: OutlineInputBorder()
                        ),
                      ),
                      SizedBox(height: 20,),
                      SizedBox(
                        width: double.infinity,
                        child: Text("Tinggi Badan", textAlign: TextAlign.left,),
                      ),
                      TextField(
                        controller: _tinggi_badan,
                        decoration: InputDecoration(
                            hintText: "Tinggi Badan",
                            border: OutlineInputBorder()
                        ),
                      ),
                      SizedBox(height: 20,),
                      SizedBox(
                        width: double.infinity,
                        child: Text("Berat Badan", textAlign: TextAlign.left,),
                      ),
                      TextField(
                        controller: _berat_badan,
                        decoration: InputDecoration(
                            hintText: "Berat Badan",
                            border: OutlineInputBorder()
                        ),
                      ),
                      SizedBox(height: 20,),
                      SizedBox(
                        width: double.infinity,
                        child: Text("Alergi Obat", textAlign: TextAlign.left,),
                      ),
                      TextField(
                        controller: _alergi_obat,
                        decoration: InputDecoration(
                            hintText: "Alergi Obat",
                            border: OutlineInputBorder()
                        ),
                      ),
                      SizedBox(height: 20,),
                      SizedBox(
                        width: double.infinity,
                        child: Text(
                          "Status Pengobatan", textAlign: TextAlign.left,),
                      ),
                      TextField(
                        controller: _status_pengobatan,
                        decoration: InputDecoration(
                            hintText: "Status Pengobatan",
                            border: OutlineInputBorder()
                        ),
                      ),
                      SizedBox(height: 20,),
                      Column(
                        children: [
                          SizedBox(
                            width: double.infinity,
                            child: Text(
                              "Jenis Kelamin", textAlign: TextAlign.left,),
                          ),
                          Row(
                            children: [
                              Radio(value: 0,
                                  groupValue: this.select,
                                  onChanged: (int? value) {
                                    onchanged(value);
                                  }),
                              Container(width: 10.0,),
                              Text("Pria")
                            ],
                          ),
                          Row(
                            children: [
                              Radio(value: 1,
                                  groupValue: this.select,
                                  onChanged: (int? value) {
                                    onchanged(value);
                                  }),
                              Container(width: 10.0,),
                              Text("Wanita")
                            ],
                          ),
                        ],
                      ),

                      ElevatedButton(onPressed: () {
                        _postData(snapshot);
                        // Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>Myhome()));
                      },
                          child: Text("Simpan Data"))

                    ],
                  ),
                )
            );
          }

    ),
            );
  }
  void _postData(context) {
    BlocProvider.of<PasienBloc>(context).add(
      CreatePasien(_nama.text, _nik.text, _tanggal_lahir.text, _umur.text,_alamat.text, _nomor_hp.text,_tinggi_badan.text,
          _berat_badan.text, _alergi_obat.text, _status_pengobatan.text,_jenin_kelamin.text,DateTime.now().microsecondsSinceEpoch.toString() ),
    );

  }

}

