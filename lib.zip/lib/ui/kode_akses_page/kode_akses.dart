import 'package:flutter/material.dart';


class kode_akses extends StatefulWidget {
  const kode_akses({Key? key}) : super(key: key);

  @override
  _kode_aksesState createState() => _kode_aksesState();
}

class _kode_aksesState extends State<kode_akses> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: SingleChildScrollView(
          child: Center(
            child: Column(
              children: [
                SizedBox(height: 100,),
                Image.asset("images/person.png", height: 200,width: 200,),
                SizedBox(height: 10,),
                Text("Nama Aplikasi", style: TextStyle(fontSize: 20),),
                SizedBox(height: 50,),
                Text("Masukan Kode Akses", style: TextStyle(fontSize: 20),),
                SizedBox(height: 10,),
                Text("Halo, Mr. James", style: TextStyle(fontSize: 20),),
                SizedBox(height: 10,),
                Padding(padding: EdgeInsets.all(60),
                    child:  Column(
                      children: [
                        TextFormField(
                          decoration: InputDecoration(
                              hintText: "kode",
                              border: OutlineInputBorder()
                          ),),
                        SizedBox(height: 20,),
                        SizedBox(height: 40, width: 400,
                        child: ElevatedButton(
                            onPressed:(){},
                            child: Text("OK"))
                        ),

                      ],
                    )

                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
