import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';


class read_data extends StatefulWidget {
  const read_data({Key? key}) : super(key: key);

  @override
  _read_dataState createState() => _read_dataState();
}

class _read_dataState extends State<read_data> {
  CollectionReference user = FirebaseFirestore.instance.collection('data2');
  final Stream<QuerySnapshot> getdeta =
  FirebaseFirestore.instance.collection('data2').snapshots();
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold
        (
        appBar: AppBar(
          title: Text("Data Firebase"),
        ),
        body: SingleChildScrollView(

          child: StreamBuilder<QuerySnapshot>(
            stream: getdeta,
            builder:  (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
              if (snapshot.hasError) {
                return Text("error");
              }

              if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 30),
                      child: CircularProgressIndicator(),
                    ));
              }
                      if (snapshot.hasData) {
                      return ListView.builder(
                      shrinkWrap: true,
                      itemCount: snapshot.data!.docs.length,
                      itemBuilder: (context, index) {
                      Map<String, dynamic> userData = snapshot.data!.docs[index]
                          .data() as Map<String, dynamic>;
                      return SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      child: Padding(
                          padding: const EdgeInsets.only(left: 20, top:  20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if(userData["name"] =="andre")
                            Text("Nama : " + userData["name"])
                          ],
                        )
                      ),
                      );
                      });
                      }
              ;
              return Text("data");
            }
          )
        ),
      ),
    );
  }
  Future<void> deleteuser(String id) {
    return user
        .doc(id)
        .delete(); // when we store data by our id then use set method
  }
}
