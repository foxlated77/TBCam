import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';


class ProductRepository{

  final _fireCloud = FirebaseFirestore.instance.collection("data2");

  Future<void> create({required String name, required String price, required String id})async{
    try{
      await _fireCloud.doc(id)
        .set({"name" : name, "birth" : price, "id" : id});

      // _fireCloud.add({"name" : name, "birth" : price, "id" : id});
    }on FirebaseException catch(e){
      if(kDebugMode)
      {
        print("Failed with error '${e.code}' : '${e.message}'");
      }

    } catch (e){
      throw Exception(e.toString());
    }
  }
}



